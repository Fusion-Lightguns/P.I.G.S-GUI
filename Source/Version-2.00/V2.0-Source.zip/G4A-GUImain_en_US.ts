<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>aboutDialog</name>
    <message>
        <location filename="about.ui" line="14"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_about.h" line="62"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about.ui" line="26"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_about.h" line="63"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; color:#62646a;&quot;&gt;Welcome to P.I.G.S GUI!!!&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; color:#62646a;&quot;&gt;P.I.G.S (Pico Infared Gun System) is a open source lightgun ecosystem by Fusion LightGuns. &lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; color:#62646a;&quot;&gt;Use this GUI to modify, burn, change player and more .&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;br/&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; color:#62646a;&quot;&gt;See more about P.I.G.S&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;a href=&quot;https://github.com/Fusion-Lightguns/P.I.G.S--Pico-Infared-Gun-System&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; font-weight:600; text-decoration: underline; color:#62646a;&quot;&gt;https://github.com/Fusion-Lightguns/P.I.G.S--Pico-Infared-Gun-System&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>guiWindow</name>
    <message>
        <location filename="guiwindow.ui" line="23"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1001"/>
        <source>P.I.G.S-GUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1576"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1115"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1600"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1112"/>
        <source>Click Here To See IR LED Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="42"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1003"/>
        <source>Save Settings [Nothing To Save Currently]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="51"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1004"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/images/pigs_logo.png&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="115"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1066"/>
        <source>LightGun Settings</source>
        <oldsource>Gun Settings</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="256"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1017"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set if rumble force feedback is enabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="259"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1019"/>
        <source>Rumble Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="160"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1008"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set if solenoid force feedback is enabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="163"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1010"/>
        <source>Solenoid Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="176"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1012"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set if solenoid full auto is enabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="179"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1014"/>
        <source>Autofire Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="272"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1021"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enabled: Access Pause Mode by holding Trigger and Button A while no IR points are visible.&lt;/p&gt;&lt;p&gt;Disabled: Access Pause Mode by pressing the Pause Mode hotkey (Button C + Select).&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Enabled is recommended for guns with less than two sub buttons. Pause Mode will always be accessible by pressing the Home Button, if available.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enabled: Pause Menu will use a scrolling layout - navigate by using Button A/B to select, and press Trigger to activate.&lt;/p&gt;&lt;p&gt;Disabled: Pause Menu options are activated with hotkeys.&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Enabled is recommended for guns with less than two sub buttons, but &lt;span style=&quot; font-weight:700;&quot;&gt;requires an LED for visual feedback!&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="275"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1023"/>
        <source>Hold to Pause Enabled</source>
        <oldsource>Simple Pause Menu</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="542"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1043"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The multiplier to be applied for the interval between solenoid activations when &lt;span style=&quot; font-style:italic;&quot;&gt;Autofire&lt;/span&gt; is enabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="460"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1038"/>
        <source>Hold-to-Pause Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="630"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1050"/>
        <source>Solenoid Fast Interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="425"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1033"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The time between solenoid activations when the trigger is held in &lt;span style=&quot; font-style:italic;&quot;&gt;Autofire&lt;/span&gt; mode.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="595"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1048"/>
        <source>Step 1: Reset Board</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="438"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1036"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The length of rumble motor activation when pulling the trigger offscreen, in ms.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="712"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1058"/>
        <source>Refresh devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="372"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1029"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The intensity of rumble force feedback events - scales from 0 (disabled) to a maximum of 255.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="507"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1040"/>
        <source>Solenoid Hold Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="608"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1049"/>
        <source>Autofire Wait Factor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="696"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1056"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The time it takes to hold the trigger after a &lt;span style=&quot; font-style:italic;&quot;&gt;single shot&lt;/span&gt; solenoid activation before transitioning to a sustained fire feedback.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="719"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1059"/>
        <source>Flash Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="680"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1053"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When &lt;span style=&quot; font-style:italic;&quot;&gt;Hold To Pause&lt;/span&gt; mode is enabled, how long should the buttons be held before Pause Mode activates?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="315"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1025"/>
        <source>Rumble Intensity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="564"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1046"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The time between solenoid activations when the trigger is held.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="753"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1065"/>
        <source>Reboot to bootloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="334"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1026"/>
        <source>Rumble Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="727"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1060"/>
        <source>Player 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="732"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1061"/>
        <source>Player 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="737"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1062"/>
        <source>Player 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="742"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1063"/>
        <source>Player 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="529"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1041"/>
        <source>Solenoid Interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="365"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1027"/>
        <source>Step 2: Refresh Devices and Pick RPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="494"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1039"/>
        <source>Step 3: Pick Player &amp; Flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="777"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1084"/>
        <source>Buttons/Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="969"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1074"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_Down_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="832"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1069"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Select.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="857"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1070"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_B_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="944"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1073"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Start.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="801"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1068"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_Left_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1084"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1078"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_C_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1213"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1087"/>
        <source>IR Visibility Test </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1307"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1089"/>
        <source>LG-42</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1314"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1090"/>
        <source>Top Shot Mod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1382"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1097"/>
        <source>Run Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1392"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1098"/>
        <source>yScale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1412"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1100"/>
        <source>xCenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1352"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1094"/>
        <source>xScale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1402"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1099"/>
        <source>Sensitivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1362"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1095"/>
        <source>yCenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1520"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1106"/>
        <source>Calibrate Profile 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1527"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1107"/>
        <source>Calibrate Profile 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1328"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1092"/>
        <source>Calibrate Profile 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1534"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1108"/>
        <source>Calibrate Profile 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="767"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1088"/>
        <source>LightGun Tests</source>
        <oldsource>Gun Tests</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1134"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1080"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_A_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/images/icons/T_A_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1109"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1079"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_Right_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/images/icons/T_Down_Key_Vintage.png&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="230"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1015"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:700; text-decoration: underline;&quot;&gt;Feedback Toggles:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="418"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1031"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:700; text-decoration: underline;&quot;&gt;Feedback Settings:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="673"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1051"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:700; text-decoration: underline;&quot;&gt;Change Player #:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="925"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1072"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Button Tester&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;With LightGun plugged in &amp;amp; port selected&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click buttons to test. Button label will turn Green if working.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click &amp;quot;Test Rumble&amp;quot; to test rumble motor.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click &amp;quot;Test Solenoid&amp;quot; for solenoid testing.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Button &amp;amp; Feedback Tester&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;With LightGun plugged in &amp;amp; port selected&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click buttons to test. Button label will turn Green if working.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click &amp;quot;Test Rumble&amp;quot; to test rumble motor.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click &amp;quot;Test Solenoid&amp;quot; for solenoid testing.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="885"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1071"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Pump.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1000"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1075"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Trigger.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1056"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1077"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Pedal.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1154"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1081"/>
        <source>FeedBack Testers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1183"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1083"/>
        <source>Test Rumble Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1169"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1082"/>
        <source>Test Solenoid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1219"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1085"/>
        <source>IR Test Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1276"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1086"/>
        <source>Enable IR Test Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1449"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1101"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;LightGun Profiles:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1500"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1104"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Memory Settings:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1507"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1105"/>
        <source>Clear Save Memory [!]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1028"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1076"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_Up_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/images/icons/T_B_Key_Vintage.png&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1301"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1091"/>
        <source>LightGun Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1322"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1110"/>
        <source>Calibration/Memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1568"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Calibrate Profiles:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1619"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1113"/>
        <source>Click Here To See LightGun Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1638"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1114"/>
        <source>Click Here To See LightGun Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="74"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1005"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:700; text-decoration: underline;&quot;&gt;PLUG IN LIGHTGUN &amp;amp; SELECT PORT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;PLUG IN LIGHTGUN &amp;amp; SELECT PORT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1684"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1116"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1697"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/G4A-GUImain_autogen/include/ui_guiwindow.h" line="1002"/>
        <source>About P.I.G.S...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.cpp" line="2172"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.cpp" line="2172"/>
        <source>Failed to open source file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
