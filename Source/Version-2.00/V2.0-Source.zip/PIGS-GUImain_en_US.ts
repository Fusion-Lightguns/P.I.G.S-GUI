<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>aboutDialog</name>
    <message>
        <location filename="about.ui" line="14"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_about.h" line="62"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_about.h" line="62"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about.ui" line="26"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_about.h" line="63"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_about.h" line="63"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; color:#62646a;&quot;&gt;Welcome to P.I.G.S GUI!!!&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; color:#62646a;&quot;&gt;P.I.G.S (Pico Infared Gun System) is a open source lightgun ecosystem by Fusion LightGuns. &lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; color:#62646a;&quot;&gt;Use this GUI to modify, burn, change player and more .&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;br/&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; color:#62646a;&quot;&gt;See more about P.I.G.S&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;a href=&quot;https://github.com/Fusion-Lightguns/P.I.G.S--Pico-Infared-Gun-System&quot;&gt;&lt;span style=&quot; font-family:&apos;Macan&apos;,&apos;Helvetica Neue&apos;,&apos;Helvetica&apos;,&apos;Arial&apos;,&apos;sans-serif&apos;; font-size:14px; font-weight:600; text-decoration: underline; color:#62646a;&quot;&gt;https://github.com/Fusion-Lightguns/P.I.G.S--Pico-Infared-Gun-System&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>guiWindow</name>
    <message>
        <location filename="guiwindow.ui" line="23"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1024"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1024"/>
        <source>P.I.G.S-GUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="54"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1026"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1026"/>
        <source>Save Settings [Nothing To Save Currently]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="78"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1027"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1027"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/images/pigs_logo.png&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="142"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1089"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1089"/>
        <source>LightGun Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="251"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1040"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1040"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set if solenoid force feedback is enabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="254"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1042"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1042"/>
        <source>Solenoid Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="267"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1044"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1044"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set if solenoid full auto is enabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="270"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1046"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1046"/>
        <source>Autofire Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="193"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1030"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1030"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:700; text-decoration: underline;&quot;&gt;Feedback Toggles:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="219"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1032"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1032"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set if rumble force feedback is enabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="222"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1034"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1034"/>
        <source>Rumble Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="235"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1036"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1036"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enabled: Access Pause Mode by holding Trigger and Button A while no IR points are visible.&lt;/p&gt;&lt;p&gt;Disabled: Access Pause Mode by pressing the Pause Mode hotkey (Button C + Select).&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Enabled is recommended for guns with less than two sub buttons. Pause Mode will always be accessible by pressing the Home Button, if available.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="238"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1038"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1038"/>
        <source>Hold to Pause Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="587"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1071"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1071"/>
        <source>Rumble Intensity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="469"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1062"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1062"/>
        <source>Rumble Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="701"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1085"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1085"/>
        <source>Step 2: Refresh Devices and Pick RPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="642"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1080"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1080"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The intensity of rumble force feedback events - scales from 0 (disabled) to a maximum of 255.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="735"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1086"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1086"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:700; text-decoration: underline;&quot;&gt;Feedback Settings:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="406"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1058"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1058"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The time between solenoid activations when the trigger is held in &lt;span style=&quot; font-style:italic;&quot;&gt;Autofire&lt;/span&gt; mode.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="619"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1076"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1076"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The length of rumble motor activation when pulling the trigger offscreen, in ms.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="767"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1088"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1088"/>
        <source>Hold-to-Pause Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="552"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1069"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1069"/>
        <source>Step 3: Pick Player &amp; Flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="565"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1070"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1070"/>
        <source>Solenoid Hold Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="748"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1087"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1087"/>
        <source>Solenoid Interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="661"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1083"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1083"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The multiplier to be applied for the interval between solenoid activations when &lt;span style=&quot; font-style:italic;&quot;&gt;Autofire&lt;/span&gt; is enabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="482"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1064"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1064"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The time between solenoid activations when the trigger is held.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="520"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1067"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1067"/>
        <source>Step 1: Reset Board</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="425"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1060"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1060"/>
        <source>Autofire Wait Factor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="447"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1061"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1061"/>
        <source>Solenoid Fast Interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="383"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1053"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1053"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:700; text-decoration: underline;&quot;&gt;Change Player #:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="390"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1055"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1055"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When &lt;span style=&quot; font-style:italic;&quot;&gt;Hold To Pause&lt;/span&gt; mode is enabled, how long should the buttons be held before Pause Mode activates?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="603"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1073"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1073"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The time it takes to hold the trigger after a &lt;span style=&quot; font-style:italic;&quot;&gt;single shot&lt;/span&gt; solenoid activation before transitioning to a sustained fire feedback.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="635"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1078"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1078"/>
        <source>Refresh devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="527"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1068"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1068"/>
        <source>Flash Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="333"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1048"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1048"/>
        <source>Player 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="338"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1049"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1049"/>
        <source>Player 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="343"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1050"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1050"/>
        <source>Player 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="348"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1051"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1051"/>
        <source>Player 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="495"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1066"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1066"/>
        <source>Reboot to bootloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1044"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1130"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1130"/>
        <source>LightGun Tests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1066"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1126"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1126"/>
        <source>Buttons/Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1090"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1110"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1110"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_Left_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1121"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1111"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1111"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Select.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1146"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1112"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1112"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_B_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1174"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1113"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1113"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Pump.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1214"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1114"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1114"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Button Tester&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;With LightGun plugged in &amp;amp; port selected&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click buttons to test. Button label will turn Green if working.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click &amp;quot;Test Rumble&amp;quot; to test rumble motor.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt; font-weight:400;&quot;&gt;- Click &amp;quot;Test Solenoid&amp;quot; for solenoid testing.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1233"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1115"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1115"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Start.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1258"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1116"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1116"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_Down_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1289"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1117"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1117"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Trigger.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1317"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1118"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1118"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_Up_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1345"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1119"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1119"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/Pedal.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1373"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1120"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1120"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_C_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1398"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1121"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1121"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_Right_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1423"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1122"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1122"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;img src=&quot;:/images/icons/T_A_Key_Vintage.png&quot; width=&quot;115&quot; height=&quot;115&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1443"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1123"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1123"/>
        <source>FeedBack Testers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1458"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1124"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1124"/>
        <source>Test Solenoid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1472"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1125"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1125"/>
        <source>Test Rumble Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1502"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1129"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1129"/>
        <source>IR Visibility Test </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1508"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1127"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1127"/>
        <source>IR Test Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1565"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1128"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1128"/>
        <source>Enable IR Test Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1590"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1136"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1136"/>
        <source>LightGun Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1596"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1131"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1131"/>
        <source>LG-42</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1608"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1132"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1132"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/images/lightguns/LG-42.png&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1616"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1133"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1133"/>
        <source>Top Shot Mod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1622"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1134"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1134"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/images/lightguns/CL.png&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1629"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1135"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1135"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/images/lightguns/CR.png&quot;/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="787"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1108"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1108"/>
        <source>Calibration/Memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="101"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1028"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1028"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:700; text-decoration: underline;&quot;&gt;Select LightGun Here &lt;br/&gt;&lt;/span&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;for GUI to fully function.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:700; text-decoration: underline;&quot;&gt; Select Lightgun PORT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="793"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1090"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1090"/>
        <source>Calibrate Profile 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="817"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1092"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1092"/>
        <source>xScale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="827"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1093"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1093"/>
        <source>yCenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="847"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1095"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1095"/>
        <source>Run Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="857"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1096"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1096"/>
        <source>yScale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="867"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1097"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1097"/>
        <source>Sensitivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="877"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1098"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1098"/>
        <source>xCenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="914"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1099"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1099"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;LightGun Profiles:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="965"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1102"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1102"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Memory Settings:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="972"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1103"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1103"/>
        <source>Clear Save Memory [!]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="985"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1104"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1104"/>
        <source>Calibrate Profile 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="992"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1105"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1105"/>
        <source>Calibrate Profile 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="999"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1106"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1106"/>
        <source>Calibrate Profile 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1033"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1107"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1107"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Calibrate Profiles:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1640"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1141"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1141"/>
        <source>P.I.G.S Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1664"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1138"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1138"/>
        <source>Click Here To See IR LED Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1683"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1139"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1139"/>
        <source>Click Here To See LightGun Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1702"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1140"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1140"/>
        <source>Click Here To See LightGun Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1713"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1145"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1145"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1737"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1143"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1143"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:20pt; text-decoration: underline;&quot;&gt;About P.I.G.S GUI!!!&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;P.I.G.S (Pico Infared Gun System) is a open source lightgun ecosystem by Fusion LightGuns. &lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Use this GUI to modify, burn, change player and more .&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:20pt; text-decoration: underline;&quot;&gt;Offical Links&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/Fusion-Lightguns/P.I.G.S--Pico-Infared-Gun-System&quot;&gt;&lt;span style=&quot; font-size:18pt; text-decoration: underline; color:#0078d7;&quot;&gt;Main Github&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/Fusion-Lightguns/P.I.G.S--Pico-Infared-Gun-System/wiki&quot;&gt;&lt;span style=&quot; font-size:18pt; text-decoration: underline; color:#0078d7;&quot;&gt;Wiki&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.fusionlightguns.com/&quot;&gt;&lt;span style=&quot; font-size:18pt; text-decoration: underline; color:#0078d7;&quot;&gt;Fusion LighGuns Website&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:20pt; text-decoration: underline;&quot;&gt;Version #&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Code ---- 1.6&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;GUI ------ 2.0&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; text-decoration: underline;&quot;&gt;About P.I.G.S GUI!!!&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:400;&quot;&gt;P.I.G.S (Pico Infared Gun System) is a open source lightgun ecosystem by Fusion LightGuns. &lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:400;&quot;&gt;Use this GUI to modify, burn, change player and more .&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; text-decoration: underline;&quot;&gt;Offical Links&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/Fusion-Lightguns/P.I.G.S--Pico-Infared-Gun-System&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0078d7;&quot;&gt;Main Github&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://github.com/Fusion-Lightguns/P.I.G.S--Pico-Infared-Gun-System/wiki&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0078d7;&quot;&gt;Wiki&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;https://www.fusionlightguns.com/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0078d7;&quot;&gt;Fusion LighGuns Website&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:18pt; text-decoration: underline;&quot;&gt;Version #&apos;s&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:400;&quot;&gt;Code ---- 1.6&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:400;&quot;&gt;GUI ------ 2.0&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.ui" line="1753"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Profile/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1025"/>
        <location filename="build/Desktop_Qt_5_15_2_MinGW_32_bit-Release/PIGS-GUImain_autogen/include/ui_guiwindow.h" line="1025"/>
        <source>About P.I.G.S...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.cpp" line="2425"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="guiwindow.cpp" line="2425"/>
        <source>Failed to open source file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
